from django.shortcuts import render
from newsapi import NewsApiClient
import datetime
from django.http import JsonResponse
import json
newsapi = NewsApiClient(api_key='6abd46329fb84bae926809fbdbb18479')

def news(request):
    articles_with_images = []
    try:
        current_date = datetime.datetime.now()
        one_month_ago = current_date - datetime.timedelta(days=30)
        current_date_str = current_date.strftime('%Y-%m-%d')
        one_month_ago_str = one_month_ago.strftime('%Y-%m-%d')
        all_articles = newsapi.get_everything(q='apple', 
                                              sources='bbc-news,the-verge', 
                                              domains='bbc.co.uk,techcrunch.com', 
                                              from_param=one_month_ago_str, 
                                              to=current_date_str, 
                                              language='en', 
                                              sort_by='relevancy', 
                                              page=1)

        for article in all_articles['articles']:
            articles_with_images.append({
                'title': article['title'],
                'description': article['description'],
                'url': article['url'],
                'urlToImage': article['urlToImage'],
                'publishedAt': article['publishedAt']
            })

    except Exception as e:
        articles_with_images = []
        print(f"An error occurred: {e}")

    return render(request, 'news.html', {'articles': json.dumps(articles_with_images)})



def SearchNewsQuery(request):
    articles_with_images = []
    try:
        query = request.POST.get('searchQuery')
        fromDate = request.POST.get('fromDate')
        toDate = request.POST.get('toDate')
        all_articles = newsapi.get_everything(q=query, 
                                              sources='bbc-news,the-verge', 
                                              domains='bbc.co.uk,techcrunch.com', 
                                              from_param=fromDate, 
                                              to=toDate, 
                                              language='en', 
                                              sort_by='relevancy', 
                                              page=1)

        for article in all_articles['articles']:
            articles_with_images.append({
                'title': article['title'],
                'description': article['description'],
                'url': article['url'],
                'urlToImage': article['urlToImage'],
                'publishedAt': article['publishedAt']
            })

    except Exception as e:
        articles_with_images = []
        print(f"An error occurred: {e}")
    return JsonResponse({'articles': articles_with_images}, safe=False)
