from django.contrib import admin
from django.urls import path,include
from myapp import views
urlpatterns = [
    path('',views.news,name='news'),
    path('search-query',views.SearchNewsQuery,name='SearchNewsQuery')
]